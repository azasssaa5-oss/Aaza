package com.liquidglass.controlcenter

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var overlay by remember { mutableStateOf(Settings.canDrawOverlays(this)) }
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0B0D12)) {
                    Column(
                        Modifier.padding(24.dp).fillMaxSize(),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "Liquid Glass Control Center",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "iOS-inspired glass control panel for Android/Xiaomi.",
                            color = Color(0xFFB8BDC8)
                        )
                        Spacer(Modifier.height(24.dp))
                        Button(
                            onClick = {
                                if (!Settings.canDrawOverlays(this@MainActivity)) {
                                    startActivity(
                                        Intent(
                                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:$packageName")
                                        )
                                    )
                                } else {
                                    startService(
                                        Intent(this@MainActivity, ControlCenterService::class.java)
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (overlay) "Start Control Center" else "Allow Overlay Permission")
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Tip: On Xiaomi/HyperOS, enable autostart and allow display-over-other-apps if the system asks.",
                            color = Color(0xFF8F95A3),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
