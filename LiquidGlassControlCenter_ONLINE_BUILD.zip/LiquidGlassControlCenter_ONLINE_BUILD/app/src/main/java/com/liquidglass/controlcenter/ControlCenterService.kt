package com.liquidglass.controlcenter

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class ControlCenterService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var view: ControlCenterView

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = ControlCenterView(this)
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        wm.addView(view, params)
    }

    override fun onDestroy() {
        if (::view.isInitialized) wm.removeView(view)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    inner class ControlCenterView(context: Context) : android.view.View(context) {

        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private var downY = 0f
        private var startY = 0f
        private var shown = false

        init {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downY = e.rawY
                        startY = e.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val d = e.rawY - startY
                        if (!shown && d > 160) {
                            shown = true
                            invalidate()
                        } else if (shown && d < -160) {
                            stopSelf()
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> true
                    else -> false
                }
            }
        }

        override fun onDraw(c: android.graphics.Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            paint.color = android.graphics.Color.argb(if (shown) 210 else 35, 8, 10, 16)
            c.drawRect(0f, 0f, w, h, paint)

            if (!shown) {
                paint.color = android.graphics.Color.argb(160, 255, 255, 255)
                c.drawRoundRect(w/2-70, 10f, w/2+70, 18f, 9f, 9f, paint)
                return
            }

            paint.setShadowLayer(45f, 0f, 12f, android.graphics.Color.argb(100,0,0,0))
            paint.color = android.graphics.Color.argb(90, 255, 255, 255)
            c.drawRoundRect(20f, 28f, w-20f, h-28f, 34f, 34f, paint)
            paint.clearShadowLayer()

            paint.color = android.graphics.Color.WHITE
            paint.textSize = 25f
            c.drawText("Control Center", 42f, 76f, paint)

            val labels = arrayOf("Wi-Fi", "Bluetooth", "Flashlight", "Airplane")
            val top = 115f
            for (i in labels.indices) {
                val col = i % 2
                val row = i / 2
                val l = 32f + col * ((w-76f)/2)
                val t = top + row * 92f
                paint.color = android.graphics.Color.argb(115,255,255,255)
                c.drawRoundRect(l,t,l+(w-92f)/2,t+76f,24f,24f,paint)
                paint.color = android.graphics.Color.WHITE
                paint.textSize = 17f
                c.drawText(labels[i], l+18f, t+45f, paint)
            }

            paint.color = android.graphics.Color.argb(115,255,255,255)
            c.drawRoundRect(32f, 310f, w-32f, 375f, 24f,24f,paint)
            paint.color = android.graphics.Color.WHITE
            paint.textSize = 16f
            c.drawText("Brightness", 52f, 349f, paint)

            c.drawRoundRect(32f, 392f, w-32f, 457f, 24f,24f,paint)
            paint.color = android.graphics.Color.WHITE
            c.drawText("Volume", 52f, 431f, paint)
        }
    }
}
