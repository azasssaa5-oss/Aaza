# Online build

This project is prepared for GitHub Actions.

1. Create a GitHub repository.
2. Upload the contents of this folder (do not upload the outer ZIP as a single file).
3. Open the Actions tab.
4. Select "Build Android APK".
5. Click "Run workflow".
6. When it finishes, open the successful run and download the artifact named:
   LiquidGlassControlCenter-debug

The workflow uses JDK 17 and Gradle 8.9 and builds the debug APK with `assembleDebug`.
