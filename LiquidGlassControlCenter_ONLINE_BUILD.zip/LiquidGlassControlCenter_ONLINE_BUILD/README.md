# Liquid Glass Control Center — FIXED

This is the corrected Android Studio project.

## Build
Open this folder in Android Studio or an Android IDE that supports Gradle 8.9 and Android Gradle Plugin 8.7.x.
Then run:
Build > Build APK(s)

The project uses compileSdk 35 and AGP 8.7.3. AGP 8.7 supports API 35 and requires Gradle 8.9 and JDK 17.

## Xiaomi / HyperOS
Allow "Display over other apps". For persistent background behavior, Xiaomi/HyperOS may also require Autostart and battery settings.

## Important
This is an overlay/control-center UI prototype. Android does not grant ordinary third-party apps unrestricted access to every system toggle. Some controls therefore need system APIs or user-approved Settings panels.
